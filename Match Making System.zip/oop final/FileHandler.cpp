#include "FileHandler.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <stdexcept>
using namespace std;

FileHandler::FileHandler()
    : usersFile("users.txt"), preferencesFile("preferences.txt"), matchesFile("matches.txt") {}

FileHandler::FileHandler(const string& uf, const string& pf, const string& mf)
    : usersFile(uf), preferencesFile(pf), matchesFile(mf) {}

// ─── USERS ───────────────────────────────────────────────
void FileHandler::saveUsers(const vector<User*>& users) {
    ofstream file(usersFile);
    if (!file.is_open())
        throw runtime_error("Cannot open " + usersFile + " for writing.");
    for (const auto* u : users)
        file << u->toFileString() << "\n";
    file.close();
}

vector<User*> FileHandler::loadUsers() {
    vector<User*> users;
    ifstream file(usersFile);
    if (!file.is_open()) return users;   // empty if file missing

    string line;
    while (getline(file, line)) {
        if (line.empty()) continue;
        istringstream ss(line);
        string token;
        getline(ss, token, '|');

        if (token == "PREMIUM") {
            // PREMIUM|id|name|age|gender|city|bio|boostCount|verified
            string sId, name, sAge, gender, city, bio, sBoost, sVerified;
            getline(ss, sId,      '|');
            getline(ss, name,     '|');
            getline(ss, sAge,     '|');
            getline(ss, gender,   '|');
            getline(ss, city,     '|');
            getline(ss, bio,      '|');
            getline(ss, sBoost,   '|');
            getline(ss, sVerified,'|');
            users.push_back(new PremiumUser(
                stoi(sId), name, stoi(sAge), gender, city, bio,
                stoi(sBoost), sVerified == "1"));
        } else {
            // id|name|age|gender|city|bio   (token already holds id)
            string name, sAge, gender, city, bio;
            getline(ss, name,   '|');
            getline(ss, sAge,   '|');
            getline(ss, gender, '|');
            getline(ss, city,   '|');
            getline(ss, bio,    '|');
            users.push_back(new User(
                stoi(token), name, stoi(sAge), gender, city, bio));
        }
    }
    file.close();
    return users;
}

// ─── PREFERENCES ─────────────────────────────────────────
void FileHandler::savePreferences(const vector<Preferences>& prefs) {
    ofstream file(preferencesFile);
    if (!file.is_open())
        throw runtime_error("Cannot open " + preferencesFile + " for writing.");
    for (const auto& p : prefs)
        file << p.toFileString() << "\n";
    file.close();
}

vector<Preferences> FileHandler::loadPreferences() {
    vector<Preferences> prefs;
    ifstream file(preferencesFile);
    if (!file.is_open()) return prefs;

    string line;
    while (getline(file, line)) {
        if (line.empty()) continue;
        istringstream ss(line);
        string sId, gender, sMin, sMax, city;
        getline(ss, sId,    '|');
        getline(ss, gender, '|');
        getline(ss, sMin,   '|');
        getline(ss, sMax,   '|');
        getline(ss, city,   '|');
        prefs.emplace_back(stoi(sId), gender, stoi(sMin), stoi(sMax), city);
    }
    file.close();
    return prefs;
}

// ─── MATCHES ─────────────────────────────────────────────
void FileHandler::saveMatches(const vector<Match>& matches) {
    ofstream file(matchesFile);
    if (!file.is_open())
        throw runtime_error("Cannot open " + matchesFile + " for writing.");
    for (const auto& m : matches)
        file << m.toFileString() << "\n";
    file.close();
}

vector<Match> FileHandler::loadMatches() {
    vector<Match> matches;
    ifstream file(matchesFile);
    if (!file.is_open()) return matches;

    string line;
    while (getline(file, line)) {
        if (line.empty()) continue;
        istringstream ss(line);
        string sU1, sU2, sScore, status;
        getline(ss, sU1,    '|');
        getline(ss, sU2,    '|');
        getline(ss, sScore, '|');
        getline(ss, status, '|');
        Match m(stoi(sU1), stoi(sU2), stoi(sScore));
        m.setStatus(status);
        matches.push_back(m);
    }
    file.close();
    return matches;
}
