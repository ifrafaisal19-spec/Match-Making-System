#ifndef FILEHANDLER_H
#define FILEHANDLER_H

#include "User.h"
#include "PremiumUser.h"
#include "Preferences.h"
#include "Match.h"
#include <vector>
#include <string>
using namespace std;

class FileHandler {
private:
    string usersFile;
    string preferencesFile;
    string matchesFile;

public:
    FileHandler();
    FileHandler(const string& usersFile, const string& prefsFile, const string& matchesFile);

    // User file operations
    void saveUsers(const vector<User*>& users);
    vector<User*> loadUsers();

    // Preferences file operations
    void savePreferences(const vector<Preferences>& prefs);
    vector<Preferences> loadPreferences();

    // Match file operations
    void saveMatches(const vector<Match>& matches);
    vector<Match> loadMatches();
};

#endif
