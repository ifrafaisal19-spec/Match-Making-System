#include "Match.h"
#include <iostream>
using namespace std;

Match::Match() : user1Id(0), user2Id(0), score(0), status("Pending") {}

Match::Match(int u1, int u2, int score) : user1Id(u1), user2Id(u2), score(score), status("Pending") {}

int Match::getUser1Id() const { return user1Id; }
int Match::getUser2Id() const { return user2Id; }
int Match::getScore() const { return score; }
string Match::getStatus() const { return status; }

void Match::setStatus(const string& s) { status = s; }

void Match::display() const {
    cout << "  Users  : " << user1Id << " <-> " << user2Id << "\n";
    cout << "  Score  : " << score << "/100\n";
    cout << "  Status : " << status << "\n";
}

string Match::toFileString() const {
    return to_string(user1Id) + "|" + to_string(user2Id) + "|" +
           to_string(score) + "|" + status;
}
