#ifndef MATCH_H
#define MATCH_H

#include <string>
using namespace std;

class Match {
private:
    int user1Id;
    int user2Id;
    int score;         // Compatibility score 0-100
    string status;     // "Pending", "Accepted", "Rejected"

public:
    Match();
    Match(int user1Id, int user2Id, int score);

    int getUser1Id() const;
    int getUser2Id() const;
    int getScore() const;
    string getStatus() const;

    void setStatus(const string& s);

    void display() const;
    string toFileString() const;
};

#endif
