#include "MatchEngine.h"
#include <algorithm>
using namespace std;

int MatchEngine::calculateScore(const User* requester, const User* candidate,
                                const Preferences& prefs) {
    int score = 0;

    // Gender match (40 pts)
    if (prefs.getPreferredGender() == "Any" ||
        prefs.getPreferredGender() == candidate->getGender())
        score += 40;

    // Age range match (30 pts)
    int age = candidate->getAge();
    if (age >= prefs.getMinAge() && age <= prefs.getMaxAge())
        score += 30;
    else {
        // Partial credit if within 5 years of range
        int delta = min(abs(age - prefs.getMinAge()), abs(age - prefs.getMaxAge()));
        if (delta <= 5) score += 15;
    }

    // City match (20 pts)
    if (prefs.getPreferredCity() == "Any" ||
        prefs.getPreferredCity() == candidate->getCity())
        score += 20;

    // Premium bonus (10 pts)
    if (candidate->getType() == "Premium")
        score += 10;

    return min(score, 100);
}

vector<Match> MatchEngine::findMatches(const User* requester,
                                       const vector<User*>& allUsers,
                                       const Preferences& prefs,
                                       int minScore) {
    // Hard rule: always match with the opposite gender only
    string requesterGender = requester->getGender();
    string oppositeGender  = (requesterGender == "Male") ? "Female" : "Male";

    vector<Match> results;
    for (const auto* candidate : allUsers) {
        if (candidate->getId() == requester->getId()) continue;

        // Skip anyone who is not the opposite gender
        if (candidate->getGender() != oppositeGender) continue;

        int score = calculateScore(requester, candidate, prefs);
        if (score >= minScore) {
            results.emplace_back(requester->getId(), candidate->getId(), score);
        }
    }
    // Sort by descending score
    sort(results.begin(), results.end(), [](const Match& a, const Match& b) {
        return a.getScore() > b.getScore();
    });
    return results;
}
