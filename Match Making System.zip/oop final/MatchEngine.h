#ifndef MATCHENGINE_H
#define MATCHENGINE_H

#include "User.h"
#include "Preferences.h"
#include "Match.h"
#include <vector>
using namespace std;

class MatchEngine {
public:
    // Calculate compatibility score between two users given requester's prefs
    static int calculateScore(const User* requester, const User* candidate,
                              const Preferences& prefs);

    // Find all matches for a given user based on their preferences
    static vector<Match> findMatches(const User* requester,
                                     const vector<User*>& allUsers,
                                     const Preferences& prefs,
                                     int minScore = 40);
};

#endif
