#include "MatchmakingSystem.h"
#include <iostream>
#include <limits>
#include <stdexcept>
#include <algorithm>
using namespace std;

// ─── Helpers ─────────────────────────────────────────────
MatchmakingSystem::MatchmakingSystem() : nextId(1) {}

MatchmakingSystem::~MatchmakingSystem() {
    for (auto* u : users) delete u;
}

int MatchmakingSystem::generateId() {
    return nextId++;
}

User* MatchmakingSystem::findUserById(int id) const {
    for (auto* u : users)
        if (u->getId() == id) return u;
    return nullptr;
}

Preferences* MatchmakingSystem::findPrefById(int id) {
    for (auto& p : preferences)
        if (p.getUserId() == id) return &p;
    return nullptr;
}

// ─── File I/O ────────────────────────────────────────────
void MatchmakingSystem::loadAll() {
    try {
        for (auto* u : users) delete u;
        users       = fileHandler.loadUsers();
        preferences = fileHandler.loadPreferences();
        matches     = fileHandler.loadMatches();

        // Determine nextId
        for (const auto* u : users)
            if (u->getId() >= nextId) nextId = u->getId() + 1;

        cout << "Data loaded successfully.\n";
    } catch (exception& e) {
        cout << "Load error: " << e.what() << "\n";
    }
}

void MatchmakingSystem::saveAll() {
    try {
        fileHandler.saveUsers(users);
        fileHandler.savePreferences(preferences);
        fileHandler.saveMatches(matches);
        cout << "Data saved successfully.\n";
    } catch (exception& e) {
        cout << "Save error: " << e.what() << "\n";
    }
}

// ─── Registration ─────────────────────────────────────────
void MatchmakingSystem::registerUser() {
    string name, gender, city, bio;
    int age;

    cout << "\n=== Register New User ===\n";
    cout << "Name   : "; cin.ignore(); getline(cin, name);
    cout << "Age    : "; cin >> age;
    cout << "Gender (Male/Female): "; cin >> gender;
    if (gender != "Male" && gender != "Female") {
        cout << "Invalid gender. Only Male or Female allowed.\n";
        return;
    }
    cout << "City   : "; cin.ignore(); getline(cin, city);
    cout << "Bio    : "; getline(cin, bio);

    if (age < 18) {
        cout << "Age must be 18 or above.\n";
        return;
    }

    int id = generateId();
    users.push_back(new User(id, name, age, gender, city, bio));
    cout << "User registered! Your ID is: " << id << "\n";
}

void MatchmakingSystem::registerPremiumUser() {
    string name, gender, city, bio;
    int age;

    cout << "\n=== Register Premium User ===\n";
    cout << "Name   : "; cin.ignore(); getline(cin, name);
    cout << "Age    : "; cin >> age;
    cout << "Gender (Male/Female): "; cin >> gender;
    if (gender != "Male" && gender != "Female") {
        cout << "Invalid gender. Only Male or Female allowed.\n";
        return;
    }
    cout << "City   : "; cin.ignore(); getline(cin, city);
    cout << "Bio    : "; getline(cin, bio);

    if (age < 18) {
        cout << "Age must be 18 or above.\n";
        return;
    }

    int id = generateId();
    users.push_back(new PremiumUser(id, name, age, gender, city, bio, 3, true));
    cout << "Premium user registered! Your ID is: " << id << "\n";
}

void MatchmakingSystem::listAllUsers() const {
    if (users.empty()) { cout << "No users registered yet.\n"; return; }
    cout << "\n=== All Users ===\n";
    for (const auto* u : users) u->displayProfile();
}

void MatchmakingSystem::viewProfile(int id) const {
    const User* u = findUserById(id);
    if (!u) { cout << "User not found.\n"; return; }
    u->displayProfile();
}

void MatchmakingSystem::deleteUser(int id) {
    for (auto it = users.begin(); it != users.end(); ++it) {
        if ((*it)->getId() == id) {
            delete *it;
            users.erase(it);
            // Remove related preferences
            preferences.erase(remove_if(preferences.begin(), preferences.end(),
                [id](const Preferences& p){ return p.getUserId() == id; }),
                preferences.end());
            cout << "User " << id << " deleted.\n";
            return;
        }
    }
    cout << "User not found.\n";
}

// ─── Preferences ─────────────────────────────────────────
void MatchmakingSystem::setPreferences(int userId) {
    User* u = findUserById(userId);
    if (!u) { cout << "User not found.\n"; return; }

    string gender, city;
    int minAge, maxAge;

    // Automatically set preferred gender to the opposite of the requester
    gender = (u->getGender() == "Male") ? "Female" : "Male";
    cout << "\n=== Set Preferences for " << u->getName() << " ===\n";
    cout << "Preferred Gender (auto-set to " << gender << " based on your profile)\n";
    cout << "Min Age: "; cin >> minAge;
    cout << "Max Age: "; cin >> maxAge;
    cout << "Preferred City (or 'Any'): "; cin.ignore(); getline(cin, city);

    if (minAge > maxAge) swap(minAge, maxAge);

    Preferences* existing = findPrefById(userId);
    if (existing) {
        existing->setPreferredGender(gender);
        existing->setMinAge(minAge);
        existing->setMaxAge(maxAge);
        existing->setPreferredCity(city);
        cout << "Preferences updated.\n";
    } else {
        preferences.emplace_back(userId, gender, minAge, maxAge, city);
        cout << "Preferences saved.\n";
    }
}

void MatchmakingSystem::viewPreferences(int userId) const {
    for (const auto& p : preferences) {
        if (p.getUserId() == userId) {
            cout << "\n=== Your Preferences ===\n";
            p.display();
            return;
        }
    }
    cout << "No preferences set. Please set preferences first.\n";
}

// ─── Matching ─────────────────────────────────────────────
void MatchmakingSystem::findMatches(int userId) {
    User* u = findUserById(userId);
    if (!u) { cout << "User not found.\n"; return; }

    Preferences* prefs = findPrefById(userId);
    if (!prefs) {
        cout << "Please set your preferences first (Option 5).\n";
        return;
    }

    vector<Match> newMatches = MatchEngine::findMatches(u, users, *prefs);

    if (newMatches.empty()) {
        cout << "No matches found. Try broadening your preferences.\n";
        return;
    }

    // Remove old matches for this user, then add new ones
    matches.erase(remove_if(matches.begin(), matches.end(),
        [userId](const Match& m){ return m.getUser1Id() == userId; }),
        matches.end());

    for (auto& m : newMatches) matches.push_back(m);

    cout << "\n=== Matches Found for " << u->getName() << " ===\n";
    int idx = 1;
    for (const auto& m : newMatches) {
        User* candidate = findUserById(m.getUser2Id());
        cout << "\n[" << idx++ << "] ";
        if (candidate) candidate->displayProfile();
        cout << "  Compatibility Score: " << m.getScore() << "/100\n";
        cout << "  Status: " << m.getStatus() << "\n";
    }
}

void MatchmakingSystem::viewMatches(int userId) const {
    User* u = findUserById(userId);
    if (!u) { cout << "User not found.\n"; return; }

    cout << "\n=== Matches for " << u->getName() << " ===\n";
    bool found = false;
    int idx = 1;
    for (const auto& m : matches) {
        if (m.getUser1Id() == userId) {
            found = true;
            User* candidate = findUserById(m.getUser2Id());
            cout << "[" << idx++ << "] ";
            if (candidate) cout << candidate->getName() << " (ID:" << candidate->getId() << ")";
            cout << " | Score: " << m.getScore() << " | Status: " << m.getStatus() << "\n";
        }
    }
    if (!found) cout << "No matches yet. Use 'Find Matches' first.\n";
}

void MatchmakingSystem::respondToMatch(int userId, int matchIndex, bool accept) {
    int idx = 1;
    for (auto& m : matches) {
        if (m.getUser1Id() == userId) {
            if (idx == matchIndex) {
                m.setStatus(accept ? "Accepted" : "Rejected");
                cout << "Match " << (accept ? "Accepted" : "Rejected") << "!\n";
                return;
            }
            idx++;
        }
    }
    cout << "Match not found.\n";
}

// ─── Main Menu ────────────────────────────────────────────
void MatchmakingSystem::run() {
    loadAll();

    int choice = 0;
    do {
        cout << "\n========================================\n";
        cout << "       MATCHMAKING SYSTEM MENU\n";
        cout << "========================================\n";
        cout << " 1. Register as Normal User\n";
        cout << " 2. Register as Premium User\n";
        cout << " 3. View All Profiles\n";
        cout << " 4. View a Profile by ID\n";
        cout << " 5. Set My Preferences\n";
        cout << " 6. View My Preferences\n";
        cout << " 7. Find Matches\n";
        cout << " 8. View My Matches\n";
        cout << " 9. Accept/Reject a Match\n";
        cout << "10. Delete My Account\n";
        cout << "11. Save & Exit\n";
        cout << "Enter choice: ";

        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input.\n";
            continue;
        }

        try {
            int id, matchIdx;
            char resp;
            switch (choice) {
                case 1:  registerUser();           break;
                case 2:  registerPremiumUser();    break;
                case 3:  listAllUsers();           break;
                case 4:
                    cout << "Enter User ID: "; cin >> id;
                    viewProfile(id);               break;
                case 5:
                    cout << "Enter Your ID: "; cin >> id;
                    setPreferences(id);            break;
                case 6:
                    cout << "Enter Your ID: "; cin >> id;
                    viewPreferences(id);           break;
                case 7:
                    cout << "Enter Your ID: "; cin >> id;
                    findMatches(id);               break;
                case 8:
                    cout << "Enter Your ID: "; cin >> id;
                    viewMatches(id);               break;
                case 9:
                    cout << "Enter Your ID: "; cin >> id;
                    cout << "Enter Match Number: "; cin >> matchIdx;
                    cout << "Accept? (y/n): "; cin >> resp;
                    respondToMatch(id, matchIdx, resp == 'y' || resp == 'Y');
                    break;
                case 10:
                    cout << "Enter Your ID to delete: "; cin >> id;
                    deleteUser(id);                break;
                case 11:
                    saveAll();
                    cout << "Goodbye!\n";          break;
                default:
                    cout << "Invalid option. Try again.\n";
            }
        } catch (exception& e) {
            cout << "Error: " << e.what() << "\n";
        }

    } while (choice != 11);
}
