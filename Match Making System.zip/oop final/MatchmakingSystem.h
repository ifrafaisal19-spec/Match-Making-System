#ifndef MATCHMAKINGSYSTEM_H
#define MATCHMAKINGSYSTEM_H

#include "User.h"
#include "PremiumUser.h"
#include "Preferences.h"
#include "Match.h"
#include "FileHandler.h"
#include "MatchEngine.h"
#include <vector>
#include <string>
using namespace std;

class MatchmakingSystem {
private:
    vector<User*>       users;
    vector<Preferences> preferences;
    vector<Match>       matches;
    FileHandler         fileHandler;
    int                 nextId;

    User* findUserById(int id) const;
    Preferences* findPrefById(int id);
    int generateId();

public:
    MatchmakingSystem();
    ~MatchmakingSystem();

    void loadAll();
    void saveAll();

    // User management
    void registerUser();
    void registerPremiumUser();
    void listAllUsers() const;
    void viewProfile(int id) const;
    void deleteUser(int id);

    // Preferences
    void setPreferences(int userId);
    void viewPreferences(int userId) const;

    // Matching
    void findMatches(int userId);
    void viewMatches(int userId) const;
    void respondToMatch(int userId, int matchIndex, bool accept);

    // Menu
    void run();
};

#endif
