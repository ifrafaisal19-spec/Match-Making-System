#include "Preferences.h"
#include <iostream>
using namespace std;

Preferences::Preferences() : userId(0), preferredGender("Any"), minAge(18), maxAge(50), preferredCity("Any") {}

Preferences::Preferences(int userId, const string& gender, int minAge, int maxAge, const string& city)
    : userId(userId), preferredGender(gender), minAge(minAge), maxAge(maxAge), preferredCity(city) {}

int Preferences::getUserId() const { return userId; }
string Preferences::getPreferredGender() const { return preferredGender; }
int Preferences::getMinAge() const { return minAge; }
int Preferences::getMaxAge() const { return maxAge; }
string Preferences::getPreferredCity() const { return preferredCity; }

void Preferences::setPreferredGender(const string& g) { preferredGender = g; }
void Preferences::setMinAge(int a) { minAge = a; }
void Preferences::setMaxAge(int a) { maxAge = a; }
void Preferences::setPreferredCity(const string& c) { preferredCity = c; }

void Preferences::display() const {
    cout << "  Preferred Gender : " << preferredGender << "\n";
    cout << "  Age Range        : " << minAge << " - " << maxAge << "\n";
    cout << "  Preferred City   : " << preferredCity << "\n";
}

string Preferences::toFileString() const {
    return to_string(userId) + "|" + preferredGender + "|" +
           to_string(minAge) + "|" + to_string(maxAge) + "|" + preferredCity;
}
