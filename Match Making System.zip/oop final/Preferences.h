#ifndef PREFERENCES_H
#define PREFERENCES_H

#include <string>
using namespace std;

class Preferences {
private:
    int userId;
    string preferredGender;
    int minAge;
    int maxAge;
    string preferredCity;

public:
    Preferences();
    Preferences(int userId, const string& gender, int minAge, int maxAge, const string& city);

    int getUserId() const;
    string getPreferredGender() const;
    int getMinAge() const;
    int getMaxAge() const;
    string getPreferredCity() const;

    void setPreferredGender(const string& g);
    void setMinAge(int a);
    void setMaxAge(int a);
    void setPreferredCity(const string& c);

    void display() const;
    string toFileString() const;
};

#endif
