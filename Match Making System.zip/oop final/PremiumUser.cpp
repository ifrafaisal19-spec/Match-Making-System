#include "PremiumUser.h"
#include <iostream>
using namespace std;

PremiumUser::PremiumUser() : User(), boostCount(0), verified(false) {}

PremiumUser::PremiumUser(int id, const string& name, int age, const string& gender,
                         const string& city, const string& bio, int boostCount, bool verified)
    : User(id, name, age, gender, city, bio), boostCount(boostCount), verified(verified) {}

int PremiumUser::getBoostCount() const { return boostCount; }
bool PremiumUser::isVerified() const { return verified; }
void PremiumUser::setBoostCount(int count) { boostCount = count; }
void PremiumUser::setVerified(bool v) { verified = v; }

void PremiumUser::displayProfile() const {
    User::displayProfile();
    cout << "Type   : PREMIUM " << (verified ? "[Verified]" : "") << "\n";
    cout << "Boosts : " << boostCount << "\n";
    cout << "-----------------------------\n";
}

string PremiumUser::getType() const { return "Premium"; }

string PremiumUser::toFileString() const {
    return "PREMIUM|" + User::toFileString() + "|" +
           to_string(boostCount) + "|" + (verified ? "1" : "0");
}
