#ifndef PREMIUMUSER_H
#define PREMIUMUSER_H

#include "User.h"
#include <string>
using namespace std;

class PremiumUser : public User {
private:
    int boostCount;      // Extra profile boosts
    bool verified;       // Verified badge

public:
    PremiumUser();
    PremiumUser(int id, const string& name, int age, const string& gender,
                const string& city, const string& bio, int boostCount, bool verified);

    int getBoostCount() const;
    bool isVerified() const;
    void setBoostCount(int count);
    void setVerified(bool v);

    void displayProfile() const override;
    string getType() const override;
    string toFileString() const override;
};

#endif
