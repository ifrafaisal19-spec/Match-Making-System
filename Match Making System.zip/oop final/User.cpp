#include "User.h"
#include <iostream>
using namespace std;

User::User() : id(0), name(""), age(0), gender(""), city(""), bio("") {}

User::User(int id, const string& name, int age, const string& gender,
           const string& city, const string& bio)
    : id(id), name(name), age(age), gender(gender), city(city), bio(bio) {}

int User::getId() const { return id; }
string User::getName() const { return name; }
int User::getAge() const { return age; }
string User::getGender() const { return gender; }
string User::getCity() const { return city; }
string User::getBio() const { return bio; }

void User::setName(const string& n) { name = n; }
void User::setAge(int a) { age = a; }
void User::setGender(const string& g) { gender = g; }
void User::setCity(const string& c) { city = c; }
void User::setBio(const string& b) { bio = b; }

void User::displayProfile() const {
    cout << "-----------------------------\n";
    cout << "ID     : " << id << "\n";
    cout << "Name   : " << name << "\n";
    cout << "Age    : " << age << "\n";
    cout << "Gender : " << gender << "\n";
    cout << "City   : " << city << "\n";
    cout << "Bio    : " << bio << "\n";
}

string User::getType() const { return "User"; }

string User::toFileString() const {
    return to_string(id) + "|" + name + "|" + to_string(age) + "|" +
           gender + "|" + city + "|" + bio;
}
