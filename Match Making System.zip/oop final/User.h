#ifndef USER_H
#define USER_H

#include <string>
using namespace std;

class User {
protected:
    int id;
    string name;
    int age;
    string gender;
    string city;
    string bio;

public:
    User();
    User(int id, const string& name, int age, const string& gender,
         const string& city, const string& bio);

    // Getters
    int getId() const;
    string getName() const;
    int getAge() const;
    string getGender() const;
    string getCity() const;
    string getBio() const;

    // Setters
    void setName(const string& name);
    void setAge(int age);
    void setGender(const string& gender);
    void setCity(const string& city);
    void setBio(const string& bio);

    // Virtual methods
    virtual void displayProfile() const;
    virtual string getType() const;
    virtual string toFileString() const;

    virtual ~User() {}
};

#endif
