#include "MatchmakingSystem.h"
#include <cstdlib>

int main() {
    system("color D0");
    
    MatchmakingSystem sys;
    sys.run();
    return 0;
}
